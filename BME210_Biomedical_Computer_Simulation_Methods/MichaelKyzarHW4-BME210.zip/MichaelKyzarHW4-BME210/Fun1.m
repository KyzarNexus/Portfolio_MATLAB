function Fk = Fun1(K,t,z,V,D)
Fk = sum(z.*t.*(exp(-K*t)))-(D/V)*sum(t.*exp(-2*K*t));
end