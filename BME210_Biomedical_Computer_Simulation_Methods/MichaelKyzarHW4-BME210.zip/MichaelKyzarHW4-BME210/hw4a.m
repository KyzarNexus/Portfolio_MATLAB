%{
Michael Kyzar
BME 210
HW 4
%}
clear; clc;
% Setting Paramaters
dose = [14,14,28,28]; % Male and Female initial dosage
modPar = ...
    [               ... % Male (Left) & Female (Right)
    13 , 10 ;       ... % V(L)
    10 , 10 ;       ... % k_s(h^-1)
    11000 , 11000 ; ... % k_a(h^-1)
    45 , 40 ;       ... % V_m(g/h)
    50 , 50         ... % K_m(g)
    ];
x0_mfmf_1 = [dose(1),0,0,dose(2),0,0];  
x0_mfmf_2 = [dose(3),0,0,dose(4),0,0];

% ODE45 Solving
tspan = 1:0.01:8;
options = odeset('RelTol',1.0e-5,'AbsTol',1.0e-5);
[tt,xxd1] = ode45(@(t,x) AlcoholPK(t,x,modPar),tspan,x0_mfmf_1,options);
[tt,xxd2] = ode45(@(t,x) AlcoholPK(t,x,modPar),tspan,x0_mfmf_2,options);
% Separating Results into usable arrays and processing for BAC
sto1m = xxd1(:,1); bac1m = xxd1(:,3)/(10*modPar(1,1));
sto1f = xxd1(:,4); bac1f = xxd1(:,6)/(10*modPar(1,2));
sto2m = xxd2(:,1); bac2m = xxd2(:,3)/(10*modPar(1,1));
sto2f = xxd2(:,4); bac2f = xxd2(:,6)/(10*modPar(1,2));

% Plotting Results
% Figure 1
figure;
% Subplot 1
subplot(2,1,1)
plot(tt,sto1m,'-y') % Male 14g
hold on
plot(tt,sto1f,'-b') % Female 14g
plot(tt,sto2m,'-r') % Male 28g
plot(tt,sto2f,'-m') % Female 28g
title('Alcohol Content (Stomach) Over 8 Hours')
xlabel('t (hours)')
ylabel('Alcohol Content (g)')
legend('Male: 14g','Female: 14g','Male: 28g','Female: 28g')
hold off
% Subplot 2
subplot(2,1,2)
plot(tt,bac1m,'-y') % Male 14g
hold on
plot(tt,bac1f,'-b') % Female 14g
plot(tt,bac2m,'-r') % Male 28g
plot(tt,bac2f,'-m') % Female 28g
title('BAC(%) Over 8 Hours')
xlabel('t (hours)')
ylabel('BAC(%)')
legend('Male: 14g','Female: 14g','Male: 28g','Female: 28g')
hold off

% Initializing indicator
tInd = 1:0.5:8;
xInd(1:length(tInd)) = 0.08;
% Figure 2
figure;
plot(tt,bac1m,'-y') % Male 14g
hold on
plot(tt,bac1f,'-b') % Female 14g
plot(tt,bac2m,'-r') % Male 28g
plot(tt,bac2f,'-m') % Female 28g
    % Plotting Indicator Lines 
plot(tInd,xInd,'--k')
title('BAC(%) Over 8 Hours')
xlabel('t (hours)')
ylabel('BAC(%)')
legend('Male: 14g','Female: 14g','Male: 28g','Female: 28g','BAC (%) Limit')
hold off
