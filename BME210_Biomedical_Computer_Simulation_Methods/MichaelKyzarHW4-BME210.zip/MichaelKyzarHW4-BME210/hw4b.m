%{
Michael Kyzar
BME 210
HW 4
%}
clear; clf; clc;
% Initializing data vectors from provided source
D = 10;
S1=[D,0.281494,0.229106,0.195422,5.02E-02,3.69E-02,2.13E-02];
S2=[D,0.277286,0.248421,0.240393,0.139422,8.47E-02,5.93E-02];
NS1=[D,0.652931,0.627057,0.416476,0.408699,0.322557,0.212801];
NS2=[D,0.384938,0.336141,0.301762,0.140283,0.105366,7.17E-02];
t = [0.0,1.0,3.0,5.0,14.0,18.0,24.0];
V = 25;


% Secant method
% Conc = (D/V)*exp(-K*t);
% For Smoke 1
a = 2;  K(1)=0.01; K(2)=0.03;
while abs(Fun1(K(a),t,S1,V,D))>0.01 % Fun1(K,t,z,V,D)
   K(a+1)=K(a)-Fun1(K(a),t,S1,V,D)*(K(a)-K(a-1))/(Fun1(K(a),t,S1,V,D)-Fun1(K(a-1),t,S1,V,D));
   a=a+1;
end
K_S1 = K(end);
S1_F = (D/V)*exp(-K_S1*t);
clear K;
% For Smoke 2
a = 2; K(1)=0.01; K(2)=0.03;
while abs(Fun1(K(a),t,S2,V,D))>0.01 % Fun1(K,t,z,V,D)
   K(a+1)=K(a)-Fun1(K(a),t,S2,V,D)*(K(a)-K(a-1))/(Fun1(K(a),t,S2,V,D)-Fun1(K(a-1),t,S2,V,D));
   a=a+1;
end
K_S2 = K(end);
S2_F = (D/V)*exp(-K_S2*t);
clear K;
% For NonSmoke 1
a = 2;  K(1)=0.01; K(2)=0.03;
while abs(Fun1(K(a),t,NS1,V,D))>0.0001 % Fun1(K,t,z,V,D)
   K(a+1)=K(a)-Fun1(K(a),t,NS1,V,D)*(K(a)-K(a-1))/(Fun1(K(a),t,NS1,V,D)-Fun1(K(a-1),t,NS1,V,D));
   a=a+1;
end
K_NS1 = K(end);
NS1_F = (D/V)*exp(-K_NS1*t);
clear K;
% For NonSmoke 2
a = 2;  K(1)=0.01; K(2)=0.03;
while abs(Fun1(K(a),t,NS2,V,D))>0.01 % Fun1(K,t,z,V,D)
   K(a+1)=K(a)-Fun1(K(a),t,NS2,V,D)*(K(a)-K(a-1))/(Fun1(K(a),t,NS2,V,D)-Fun1(K(a-1),t,NS2,V,D));
   a=a+1;
end
K_NS2 = K(end);
NS2_F = (D/V)*exp(-K_NS2*t);
clear K;
% Plotting
% S1
subplot(2,2,1)
hold on
title('Smoking 1')
xlabel('t (hours)')
ylabel('c(t) (mg/L)')
axis([0 24 0.0 0.8])
plot(t,S1_F,'-k')
plot(t,S1,'o')
legend(['System Model (K = ',num2str(K_S1),')'],'Raw Data')
% S2
subplot(2,2,2)
hold on
title('Smoking 2')
xlabel('t (hours)')
ylabel('c(t) (mg/L)')
axis([0 24 0.0 0.8])
plot(t,S2_F,'-k')
plot(t,S2,'o')
legend(['System Model (K = ',num2str(K_S2),')'],'Raw Data')
% NS1
subplot(2,2,3)
hold on
title('NonSmoking 1')
xlabel('t (hours)')
ylabel('c(t) (mg/L)')
axis([0 24 0.0 0.8])
plot(t,NS1_F,'-k')
plot(t,NS1,'o')
legend(['System Model (K = ',num2str(K_NS1),')'],'Raw Data')
% NS2
subplot(2,2,4)
hold on
title('NonSmoking 2')
xlabel('t (hours)')
ylabel('c(t) (mg/L)')
axis([0 24 0.0 0.8])
plot(t,NS2_F,'-k')
plot(t,NS2,'o')
legend(['System Model (K = ',num2str(K_NS2),')'],'Raw Data')




















