function f = Fun2(param,kv)
t = [1.0,3.0,5.0,14.0,18.0,24.0];
D = 10;
f = sum((param-(D/kv(2)).*exp(-kv(1)*t)).^2);
end