function [dxdt] = AlcoholPK(t,x, modPar)
% ALCOHOLPK Creates a set of differential equations based on parameters.
% Input(s):
%   - An Array of current x values
%   - A (5x2 matrix of parameters under the following convention:
%       - Male Left and Female Right, R1: V(L), R2: k_s, R3: k_a,
%         R4: V_m, R5: K_m
% Output: An array of current rates of change. The first three are for
% males. The last three are for females.

% Initializing Coefficients from modPar
k_s_m = modPar(2,1); k_a_m = modPar(3,1); V_m_m = modPar(4,1);
K_m_m = modPar(5,1);    % Male Parameters
k_s_f = modPar(2,2); k_a_f = modPar(3,2); V_m_f = modPar(4,2);
K_m_f = modPar(5,2);    % Female Parameters

% Set of Differential Equations
dxdt = [ ...
    % Male
    -k_s_m*x(1);                          ... % dx1/dt 
    k_s_m*x(1)-k_a_m*x(2);                ... % dx2/dt 
    k_a_m*x(2)-(V_m_m*x(3))/(K_m_m+x(3)); ... % dx3/dt 
    % Female
    -k_s_f*x(1);                          ... % dx1/dt 
    k_s_f*x(1)-k_a_f*x(2);                ... % dx2/dt 
    k_a_f*x(2)-(V_m_f*x(3))/(K_m_f+x(3)); ... % dx3/dt 
    ];
end
