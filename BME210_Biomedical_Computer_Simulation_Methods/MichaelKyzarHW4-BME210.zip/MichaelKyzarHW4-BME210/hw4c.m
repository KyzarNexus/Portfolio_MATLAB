%{
Michael Kyzar
BME 210
HW 4
%}
clear; clc;
% Raw Data
D = 10;
S1=[0.281494,0.229106,0.195422,5.02E-02,3.69E-02,2.13E-02];
S2=[0.277286,0.248421,0.240393,0.139422,8.47E-02,5.93E-02];
NS1=[0.652931,0.627057,0.416476,0.408699,0.322557,0.212801];
NS2=[0.384938,0.336141,0.301762,0.140283,0.105366,7.17E-02];
t = [1.0,3.0,5.0,14.0,18.0,24.0];

kvguess = [0.1, 0.001];
% S1
kvout1 = fminsearch(@(kv) Fun2(S1,kv),kvguess);
C1 = (D/kvout1(2))*exp(-kvout1(1)*t);
% S2
kvout2 = fminsearch(@(kv) Fun2(S2,kv),kvguess);
C2 = (D/kvout2(2))*exp(-kvout2(1)*t);
% NS1
kvout3 = fminsearch(@(kv) Fun2(NS1,kv),kvguess);
C3 = (D/kvout3(2))*exp(-kvout3(1)*t);
% NS2
kvout4 = fminsearch(@(kv) Fun2(NS2,kv),kvguess);
C4 = (D/kvout4(2))*exp(-kvout4(1)*t);

% Plotting
% S1
subplot(2,2,1)
hold on
title('Smoking 1')
xlabel('t (hours)')
ylabel('c(t) (mg/L)')
axis([0 24 0.0 0.8])
plot(t,C1,'-k')
plot(t,S1,'o')
legend(['System Model (K,V = ',num2str(kvout1(1)),',',num2str(kvout1(2)),')'],'Raw Data')
% S2
subplot(2,2,2)
hold on
title('Smoking 2')
xlabel('t (hours)')
ylabel('c(t) (mg/L)')
axis([0 24 0.0 0.8])
plot(t,C2,'-k')
plot(t,S2,'o')
legend(['System Model (K,V = ',num2str(kvout2(1)),',',num2str(kvout2(2)),')'],'Raw Data')
% NS1
subplot(2,2,3)
hold on
title('NonSmoking 1')
xlabel('t (hours)')
ylabel('c(t) (mg/L)')
axis([0 24 0.0 0.8])
plot(t,C3,'-k')
plot(t,NS1,'o')
legend(['System Model (K,V = ',num2str(kvout3(1)),',',num2str(kvout3(2)),')'],'Raw Data')
% NS2
subplot(2,2,4)
hold on
title('NonSmoking 2')
xlabel('t (hours)')
ylabel('c(t) (mg/L)')
axis([0 24 0.0 0.8])
plot(t,C4,'-k')
plot(t,NS2,'o')
legend(['System Model (K,V = ',num2str(kvout4(1)),',',num2str(kvout4(2)),')'],'Raw Data')








