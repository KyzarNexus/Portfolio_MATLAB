%{
    Michael Kyzar
    ITP 168, Spring 2016
    Lab 12
    kyzar@usc.edu

    Revision History
Date        Changes         Programmer
----------------------------------------
10/12/2016  First Draft     Michael Kyzar
%}

clear; clc;

X=randi(10,1,10);

mySTDEV(X)