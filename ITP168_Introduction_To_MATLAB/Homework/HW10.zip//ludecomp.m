function [ L, U ] = ludecomp( inputMatrix )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
%{
    Michael Kyzar
    ITP 168, Fall 2016
    Homework 10
    kyzar@usc.edu

    Revision History
Date        Changes         Programmer
----------------------------------------
11/29/2016  First Draft     Michael Kyzar
%}

[nrow, ncol]=size(inputMatrix);
if nrow>ncol
    error('Matrix dimentions do not support LU decomposition')
end
L=eye(nrow);
U=inputMatrix;
for c=1:nrow-1
    for r=c+1:nrow 
        f=-(U(r,c)/U(c,c));
        U(r,:)=U(r,:)+f*U(c,:);
        lTemp=eye(nrow);
        lTemp(r,:)=lTemp(r,:)+f*lTemp(c,:);
        L=L*(lTemp^(-1));
    end
end

end

